# Dedicated $100K-$1M ML amount specialist

## Direct strict-LFYO audit on true band cases
- n: **108**
- Median baseline MAE: **USD 203,087**
- Dedicated ML MAE: **USD 187,157**
- Median baseline RMSE: **USD 265,957**
- Dedicated ML RMSE: **USD 247,802**
- Median baseline log-MAE: **0.5986**
- Dedicated ML log-MAE: **0.5448**
- Dedicated ML unique predictions: **108**

## Frozen-router deployable audit for rows routed to $100K-$1M
- n: **130**
- Median baseline MAE: **USD 433,993**
- Dedicated ML MAE: **USD 415,768**
- Median baseline RMSE: **USD 878,411**
- Dedicated ML RMSE: **USD 869,533**

## Model selection
- Selected models by fold: **{'lgbm_log_sem': 4, 'et_log_current': 6, 'et_log_sem': 4, 'rf_log_sem': 1}**
- Selected shrinkage weights by fold: **{1.0: 15}**
- Fraction of folds where inner-selected ML beat inner median: **100.0%**

## Decision
- **Dedicated ML beats the strict-LFYO median on direct MAE.**

The frozen router remains unchanged; this audit only tests the amount specialist.