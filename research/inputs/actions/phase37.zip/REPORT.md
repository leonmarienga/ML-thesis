# Phase37 — Independent rainfall and observed streamflow versus NOAA report-density signals

This is an explicitly exploratory feature-family audit, NOT independent validation or an accepted model upgrade.

## 59-case fiscal-year forward-test metrics

| arm                                  |   n |   MAE_USD |         RMSE_USD |       R2 |   six_band_accuracy |   n_positive |   positive_target_MAE_USD |
|:-------------------------------------|----:|----------:|-----------------:|---------:|--------------------:|-------------:|--------------------------:|
| fema_normalized_report_density       |  59 |    355021 | 856456           | 0.790144 |            0.847458 |           31 |          675685           |
| fema_density_plus_rain_presence      |  59 |    358124 | 873493           | 0.781712 |            0.847458 |           31 |          681591           |
| fema_geo_event_counts                |  59 |    384133 | 925578           | 0.754903 |            0.847458 |           31 |          731092           |
| fema_density_plus_multiloc_rain_usgs |  59 |    386320 | 957980           | 0.737443 |            0.847458 |           31 |          735253           |
| fema_density_plus_multiloc_rain      |  59 |    404804 |      1.02588e+06 | 0.698904 |            0.830508 |           31 |          770434           |
| fema_rain_presence_only              |  59 |    527706 |      1.34353e+06 | 0.483575 |            0.762712 |           31 |               1.00434e+06 |
| fema_single_rain_magnitude           |  59 |    530415 |      1.34573e+06 | 0.481887 |            0.745763 |           31 |               1.0095e+06  |
| fema_multiloc_rain_plus_usgs         |  59 |    536317 |      1.35372e+06 | 0.475715 |            0.762712 |           31 |               1.02073e+06 |
| fema_only                            |  59 |    537057 |      1.36405e+06 | 0.46768  |            0.762712 |           31 |               1.02214e+06 |
| fema_multiloc_rain                   |  59 |    538105 |      1.36021e+06 | 0.470674 |            0.762712 |           31 |               1.02414e+06 |

## Exploratory paired comparisons

| arm                                  |   mean_MAE_change_new_minus_FEMA_USD |   improved |   worsened |   unchanged |   FY_bootstrap_interval_low_USD |   FY_bootstrap_interval_high_USD |
|:-------------------------------------|-------------------------------------:|-----------:|-----------:|------------:|--------------------------------:|---------------------------------:|
| fema_normalized_report_density       |                          -182036     |         19 |         12 |          28 |                      -447308    |                       -18839.1   |
| fema_density_plus_rain_presence      |                          -178933     |         21 |         10 |          28 |                      -449488    |                       -12045.7   |
| fema_geo_event_counts                |                          -152924     |         22 |         11 |          26 |                      -371722    |                       -11131.1   |
| fema_density_plus_multiloc_rain_usgs |                          -150738     |         19 |         12 |          28 |                      -384568    |                       -10204.5   |
| fema_density_plus_multiloc_rain      |                          -132253     |         19 |         12 |          28 |                      -362958    |                        -3253.55  |
| fema_rain_presence_only              |                            -9350.56  |         19 |         13 |          27 |                       -22820.2  |                         -634.521 |
| fema_single_rain_magnitude           |                            -6641.78  |         15 |         17 |          27 |                       -23068.7  |                          706.802 |
| fema_multiloc_rain_plus_usgs         |                             -739.515 |         11 |         20 |          28 |                       -16071.8  |                        22865.4   |
| fema_multiloc_rain                   |                             1047.87  |         14 |         17 |          28 |                        -4519.96 |                        13730.2   |

## Physical source coverage and declaration-time limits

|   flood_declarations |   single_daymet_observed |   multi_daymet_observed |   multi_site_two_or_more |   usgs_hydrology_observed |   rainfall_asof_certified |   flood_footprint_certified |   usgs_fema_causation_certified |   usgs_asof_certified |
|---------------------:|-------------------------:|------------------------:|-------------------------:|--------------------------:|--------------------------:|----------------------------:|--------------------------------:|----------------------:|
|                   92 |                       87 |                      87 |                       82 |                        11 |                         0 |                           0 |                               0 |                     0 |

## Direct paired comparisons vs report density

| arm                                  |   n |   mean_MAE_change_new_minus_density_USD |   FY_bootstrap_low_USD |   FY_bootstrap_high_USD |   improved_case_n |   worsened_case_n |   unchanged_case_n |   gain_without_three_largest_improvements_USD |   leave_three_best_case_out_mean_delta_USD |
|:-------------------------------------|----:|----------------------------------------:|-----------------------:|------------------------:|------------------:|------------------:|-------------------:|----------------------------------------------:|-------------------------------------------:|
| fema_only                            |  59 |                               182036    |               18839.1  |                447308   |                12 |                19 |                 28 |                                  -1.20219e+07 |                                  214677    |
| fema_rain_presence_only              |  59 |                               172685    |               18204.6  |                424488   |                11 |                21 |                 27 |                                  -1.13978e+07 |                                  203532    |
| fema_single_rain_magnitude           |  59 |                               175394    |               18482.9  |                424381   |                11 |                21 |                 27 |                                  -1.1406e+07  |                                  203679    |
| fema_multiloc_rain                   |  59 |                               183084    |               17452.7  |                455917   |                10 |                21 |                 28 |                                  -1.1793e+07  |                                  210589    |
| fema_multiloc_rain_plus_usgs         |  59 |                               181296    |               18795.7  |                462067   |                12 |                19 |                 28 |                                  -1.17312e+07 |                                  209485    |
| fema_geo_event_counts                |  59 |                                29112.1  |                7708.02 |                 75586.5 |                16 |                17 |                 26 |                                  -2.628e+06   |                                   46928.5  |
| fema_density_plus_rain_presence      |  59 |                                 3103.08 |               -6184.07 |                 10065.8 |                17 |                14 |                 28 |                             -405481           |                                    7240.73 |
| fema_density_plus_multiloc_rain      |  59 |                                49783    |               15585.5  |                 82840.6 |                11 |                20 |                 28 |                                  -3.39852e+06 |                                   60687.9  |
| fema_density_plus_multiloc_rain_usgs |  59 |                                31298.3  |                8634.6  |                 62740.4 |                12 |                19 |                 28 |                                  -2.20899e+06 |                                   39446.2  |

## Scope
Daymet is actual gridded precipitation at sampled NOAA coordinates, but not a validated flood footprint. USGS has only 11 usable flow cases. No declaration-time certified source versions. Repeatedly inspected 2021–2024 test results are exploratory and never independent confirmation. Frozen Track A remains untouched.
