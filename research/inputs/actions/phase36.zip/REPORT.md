# Phase36 — Reporting intensity and normalized hazard-count sensitivity

This is an explicitly exploratory feature-family audit, NOT independent validation or an accepted model upgrade.

## 59-case fiscal-year forward-test metrics

| arm                                  |   n |   MAE_USD |         RMSE_USD |       R2 |   six_band_accuracy |   n_positive |   positive_target_MAE_USD |
|:-------------------------------------|----:|----------:|-----------------:|---------:|--------------------:|-------------:|--------------------------:|
| fema_normalized_report_density       |  59 |    355021 | 856456           | 0.790144 |            0.847458 |           31 |          675685           |
| fema_normalized_plus_prior_reporting |  59 |    361158 | 893987           | 0.771349 |            0.830508 |           31 |          687365           |
| fema_geo_event_counts                |  59 |    384133 | 925578           | 0.754903 |            0.847458 |           31 |          731092           |
| fema_normalized_plus_prior_and_rain  |  59 |    396027 | 996215           | 0.716066 |            0.830508 |           31 |          753729           |
| fema_geo_event_counts_plus_rain      |  59 |    423531 |      1.056e+06   | 0.680966 |            0.847458 |           31 |          806075           |
| fema_prior_reporting_only            |  59 |    460143 |      1.1413e+06  | 0.627341 |            0.745763 |           31 |          875755           |
| fema_only                            |  59 |    537057 |      1.36405e+06 | 0.46768  |            0.762712 |           31 |               1.02214e+06 |
| fema_multiloc_rain                   |  59 |    538105 |      1.36021e+06 | 0.470674 |            0.762712 |           31 |               1.02414e+06 |

## Exploratory paired comparisons

| arm                                  |   mean_MAE_change_new_minus_FEMA_USD |   improved |   worsened |   unchanged |   FY_bootstrap_interval_low_USD |   FY_bootstrap_interval_high_USD |
|:-------------------------------------|-------------------------------------:|-----------:|-----------:|------------:|--------------------------------:|---------------------------------:|
| fema_normalized_report_density       |                           -182036    |         19 |         12 |          28 |                      -447308    |                       -10131.7   |
| fema_normalized_plus_prior_reporting |                           -175899    |         22 |          9 |          28 |                      -472194    |                        -6475.34  |
| fema_geo_event_counts                |                           -152924    |         22 |         11 |          26 |                      -371722    |                       -11131.1   |
| fema_normalized_plus_prior_and_rain  |                           -141030    |         19 |         12 |          28 |                      -379032    |                         2818.78  |
| fema_geo_event_counts_plus_rain      |                           -113526    |         17 |         16 |          26 |                      -273481    |                        -8027.6   |
| fema_prior_reporting_only            |                            -76914.4  |         17 |         16 |          26 |                      -240543    |                          708.029 |
| fema_multiloc_rain                   |                              1047.87 |         14 |         17 |          28 |                        -4519.96 |                        13730.2   |

## Scope
Past NOAA county reporting frequency is a proxy for both weather frequency and reporting practices. It does not distinguish these causally. Current FEMA designated counties and finalized NOAA records are retrospective.
