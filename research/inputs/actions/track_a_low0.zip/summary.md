# Dedicated $0-$100K two-stage ML amount specialist

- Direct n: **699**
- Median baseline MAE: **USD 4,483**
- Two-stage ML MAE: **USD 2,936**
- Median baseline RMSE: **USD 15,444**
- Two-stage ML RMSE: **USD 10,585**
- Median zero accuracy: **80.5%**
- ML zero accuracy: **95.3%**
- ML unique predictions: **145**

Decision: **ML beats the strict-LFYO median on direct MAE.**