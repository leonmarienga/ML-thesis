# Phase 34 — NOAA event universe for FEMA flood designated areas

## Status

Official FEMA designated areas + incident dates joined to all NOAA core flood/flash-flood/coastal/lakeshore event reports at county and date. The results are **candidate co-occurrences**, NOT certified FEMA flood footprints or total economic losses. Retrospective-only.

Original FEMA floods: 92; FEMA API matches: 92; cases with strict county+date+flood candidates: 79; cases with nonmissing unambiguous damage reports: 79.

Candidate strict links: 3396; shared-across-FEMA ambiguous links: 0.

## Exploratory same-cohort chronological model comparison

| arm                                    |   n |   MAE_USD |         RMSE_USD |       R2 |   six_band_accuracy |
|:---------------------------------------|----:|----------:|-----------------:|---------:|--------------------:|
| fema_multi_rain                        |  59 |    538105 |      1.36021e+06 | 0.470674 |            0.762712 |
| fema_multi_rain_noaa_damage_candidates |  59 |    434496 |      1.11039e+06 | 0.647256 |            0.847458 |
| fema_noaa_damage_candidates            |  59 |    409878 | 995300           | 0.716588 |            0.847458 |
| fema_only                              |  59 |    537057 |      1.36405e+06 | 0.46768  |            0.762712 |

## Caveats

Final NOAA estimates have no confirmed declaration-time version; FEMA source designations may be recorded after declaration; geographic and temporal co-occurrence is insufficient to establish causal attribution. These are source-integrity findings and a repeatedly inspected retrospective 59-case sample. Preserve frozen Track A.
